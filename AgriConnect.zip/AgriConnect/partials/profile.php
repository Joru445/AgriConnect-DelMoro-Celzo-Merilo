<section id="profile">
  <h2>Profile</h2>
  <div class="profile-header">
    <div class="profile-image-placeholder">
      
    </div>
    <div class="profile-info">
    </div>
  </div>
  <div class="products-section">
    <h2>My Products</h2>
    <div class="products-grid"></div>
  </div>
  
  <div id="profileScrollEnd" style="width: 100%; height: 1rem;"></div>
</section>